p = "pov3d/engine2d.html"
t = open(p, encoding="utf-8").read()
tag = '<script src="cena2d_apollo_extra.js"></script>'
if tag not in t:
    i = t.rfind("</body>")
    assert i > 0, "sem </body>"
    t = t[:i] + tag + "\n" + t[i:]
    open(p, "w", encoding="utf-8").write(t)
    print("tag inserida")
else:
    print("tag ja existe")
